import { BorderedBoxDirective } from './bordered-box.directive';

describe('BorderedBoxDirective', () => {
  it('should create an instance', () => {
    const directive = new BorderedBoxDirective();
    expect(directive).toBeTruthy();
  });
});
