import { ContactComponentRoutingModule } from './contact-component-routing';
import { NgModule } from '@angular/core';

@NgModule({
    imports:[
        ContactComponentRoutingModule
    ]
})

export class ContactComponentModule{

}