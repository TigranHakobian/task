import { Directive } from '@angular/core';

@Directive({
  selector: '[appBorderBox]'
})
export class Border.BoxDirective {

  constructor() { }

}
