import { BlockCopyPasteDirective } from './block-copy-paste.directive';

describe('BlockCopyPasteDirective', () => {
  it('should create an instance', () => {
    const directive = new BlockCopyPasteDirective();
    expect(directive).toBeTruthy();
  });
});
