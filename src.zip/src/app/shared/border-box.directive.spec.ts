import { Border.BoxDirective } from './border.box.directive';

describe('Border.BoxDirective', () => {
  it('should create an instance', () => {
    const directive = new Border.BoxDirective();
    expect(directive).toBeTruthy();
  });
});
