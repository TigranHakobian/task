import { NotFoundRoutingModule } from './not-found-routing';
import { NgModule } from '@angular/core';

@NgModule({
    imports:[
        NotFoundRoutingModule
    ]
})

export class NotFoundModule{
    
}